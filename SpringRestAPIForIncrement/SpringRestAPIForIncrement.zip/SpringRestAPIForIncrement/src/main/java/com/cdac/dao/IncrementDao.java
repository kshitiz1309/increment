package com.cdac.dao;

public interface IncrementDao {
	public int doIncrementWithLock() ;
}
